import { Routes } from '@angular/router';
import { CrudComponent } from './core/crud/crud.component';

export const routes: Routes = [
  {
    component:CrudComponent,
    path:'crud'
  }
];
