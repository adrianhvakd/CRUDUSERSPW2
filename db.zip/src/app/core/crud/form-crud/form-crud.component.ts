import { Component, inject, signal,OnInit,output,input } from '@angular/core';

import { ReactiveFormsModule,FormBuilder, FormGroup, Validators } from '@angular/forms';
import { sign } from 'crypto';
import { FirebaseService, PATHFireBase } from '../../../services/firebase.service';
import { v4 as uuidv4 } from 'uuid';
import { UsuarioModel } from '../../../models/usuario.model';

@Component({
  selector: 'app-form-crud',
  imports: [ReactiveFormsModule],
  templateUrl: './form-crud.component.html',
  styleUrl: './form-crud.component.css'
})
export class FormCrudComponent implements OnInit {
  salir = output<boolean>();
  data = input<UsuarioModel|null>(null);
  fb = inject(FormBuilder);
  datosFormGroup=this.fb.group({
        name:[this.data()?this.data()?.name:'',[Validators.required,Validators.minLength(3)]],
        email:[this.data()?this.data()?.email:'',[Validators.required,Validators.email]]
      });
  ngOnInit(){
    this.datosFormGroup.setValue({
      name:this.data()?.name,
      email:this.data()?.email,
    });
  }
  error = signal<string>('');
  editando=signal<boolean>(false);
  dbFire = inject(FirebaseService);
  enviar(){

  }
  guardar(){
    Object.keys(this.datosFormGroup.controls).forEach(key=>{
      this.datosFormGroup.get(key)?.markAsTouched();
    })
    if(this.datosFormGroup.invalid){
      this.error.set('Corregir los errores');
      return;
    }
    const data = {
      name:this.datosFormGroup.value.name,
      email:this.datosFormGroup.value.email,
    }
    if(this.editando()){
      //editando
    }
    else{
      //nuevo
      const uid=uuidv4();
      this.dbFire.add(PATHFireBase.Usuarios,uid,data);
      this.salir.emit(true);
    }
  }
  hasError(field:string){
    const control = this.datosFormGroup.get(field);
    return !!(control && control.invalid && control.touched)
  }
  getErrorMessage(field:string):string{
    const control1 = this.datosFormGroup.get(field);
    if(!control1?.errors)
      return '';
    if(control1?.errors['required'])
      return 'Este campo es obligatorio';
    if(control1?.errors['email'])
      return 'Este campo no es un email valido';
    if(control1?.errors['minlength'])
      return 'Este campo debe tener un minimo de '+control1.errors['minlength'].requiredLength;
    return '';
  }
}
