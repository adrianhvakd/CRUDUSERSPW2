export interface UsuarioModel{
  id:string,
  name:string,
  email:string
}
